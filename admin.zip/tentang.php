<?php
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="bookmark" href="favicon_16.ico"/>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Web GENIUS 2016">
    <meta name="author" content="OSIS SBBS dan ANTARES (c) 2015">
    <title>GENIUS 2016</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/global.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <h3 style="color:#FFFFFF">Halaman Administrasi GENIUS 2016<small>(<?php echo $_SESSION['username']?>)</h3>
    </div>
  </div>
</nav>

<div class="sidebar">
  <ul class="nav nav-sidebar">
    <li >
      <a href="index.php"><span class="glyphicon glyphicon-home"></span><span class="link-text">Beranda</span></a>
    </li>
    <li  >
      <a href="peserta.php"><span class="glyphicon glyphicon-user"></span><span class="link-text">Daftar Peserta</span></a>
    </li>
    <li  >
      <a href="tes.php"><span class="glyphicon glyphicon-tasks"></span><span class="link-text">Tes Online</span></a>
    </li>
    <li  class="active" >
      <a href="tentang.php"><span class="glyphicon glyphicon-phone"></span><span class="link-text">Tentang</span></a>
    </li>
  </ul>

  <ul class="nav nav-sidebar right">
    <li><a href="set.logout.php"><span class="glyphicon glyphicon-log-out"></span><span class="link-text">Logout</span></a></li>
  </ul>
</div>
<div class="page-container-full" style="margin:20px;">
	<div class="page-header">
		<h1>Tentang</h1>
		<p>Berbagai informasi mengenai GENIUS 2016</p>
	</div>
	<div >
    <h4>Sejarah GENIUS</h4>
    <p>GENIUS merupakan singkatan dari Genbilboards English N’ Science Cups. Kompetisi ini bertujuan mengembangkan minat dan potensi siswa dalam bidang matematika, sains, dan bahasa Inggris dan mempersiapkan siswa dalam menghadapi Ujian Nasional dan Olimpiade Sains Nasional. GENIUS telah dibentuk sejak SMA Negeri Sragen Bilingual Boarding School dibangun pada tahun 2008 silam.
    <h5>GENIUS 2010</h5>
    GENIUS pertama kali diselenggarakan untuk murid SMP/MTs/Sederajat Se-Karesidenan Surakarta dengan nama GENIUS 				2010 pada tanggal 10 Maret 2010. GENIUS 2010 telah berhasil diselenggarakan dengan baik. Juara pertama dari GENIUS 2010 adalah SMP Kristen Kalam Kudus Surakarta
    <h5>GENIUS 2011</h5>
    Mengingat sambutan positif dari peserta lomba, GENIUS pun diadakan lagi pada tahun 2011. GENIUS 2011 diselenggarakan untuk tingkat Jawa Tengah dan DIY. SMP Kristen Kalam Kudus berhasil mempertahankan gelarnya pada tahun ini.
    <h5>GENIUS 2012</h5>
    GENIUS 2012 akhirnya dilaksanakan di tahun berikutnya dengan tingkat Jawa – Bali Terbuka. Penyisihan pada tanggal 4 Februari 2012 yang dilanjutkan Perempat final, Semifinal, dan Final pada tanggal 11 Februari 2012. Juara pertama dari GENIUS 2012 adalah SMP N 2 Jember.
    <h5>GENIUS 2013</h5>
    Kemudian pada tahun 2013, kami juga telah merealisasikan GNIUS 2013 tingkat Nasional sebagai bukti bahwa GENIUS memiliki visi yang kokoh dalam mencerdaskan kehidupan bangsa. Untuk edisi kali ini, juara pertama diraih oleh SMP IPH ( Insan Permata Hati ) Surabaya
    <h5>GENIUS 2014</h5>
    Dalam upaya besar kami, yang begitu peduli dengan masa depan bangsa. GENIUS 2014 hadir sebagai sarana bagi remaja-remaja Indonesia untuk mengembangkan bakat mereka di bidang Sains dan Bahasa Inggris. Sehingga kelak, akan tercipta insan-insan yang mampu mengharumkan nama bangsa dan mampu berbicara banyak kepada dunia. GENIUS 2014 ini dilaksanakan untuk tingkat Nasional, dan berhasil meraih peserta dari seluruh Indonesia, termasuk pulau Sumatra dan Kalimantan. Juara pertama untuk GENIUS 2015 diraih oleh SMP N 1 Lamongan.
    <h5>GENIUS 2015</h5>
    Kemudian pada tahun 2015, OSIS SMA N SBBS kembali menggelar event akbar ini. Dengan visi yang semakin bervariasi, lomba ini kembali menarik minat siswa di seluruh pejuru negeri. Juara pertama untuk tahun 2015 adalah SMP BPK Penabur Cirebon 
    </p>
    <h4>Informasi GENIUS 2016</h4>
    <p>
    GENIUS (Genbilboards English N’ Science Cups) adalah ajang kompetisi bergengsi dalam bidang Sains (Matematika, Biologi, dan Fisika) dan Bahasa Inggris tingkat SMP Sederajat dalam lingkup nasional terbuka dengan sistem online dan offline.
    </p>
    <h4>Kontak GENIUS 2016</h4>
    <p>
    Sragen Bilingual Boarding School
	<br>Jl. Gemolong Asri No. 1, Gemolong,
	<br>Sragen 57274
	<br>Jawa Tengah, Indonesia
    <br>
    <br>Telp:
    <br>0812-2763-3323 (Anditya)
    <br>0822-4227-3321 (Dhimas)
    <br>
    <br>Fax: (0271) 6811662
    <br>
    <br>geniussbbs@gmail.com
    <br>Follow Us!
    </p>
    <h4>Tentang Perangkat Lunak GENIUS 2016</h4>
    <p>
    </p>
    </div>
</div>  
	<script src="/js/jquery-1.11.3.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
</body>
</html>