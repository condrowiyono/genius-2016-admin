<?php
     $server = "localhost";
     $username = "root"; 
     $password = "root"; 
     $db = "genius2016";
	 $link = mysqli_connect($server, $username, $password, $db)
	         or die("Salah server, nama pengguna, atau passwordnya!");
?>